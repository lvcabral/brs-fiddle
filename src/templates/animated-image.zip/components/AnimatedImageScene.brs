function init()
    timer = m.top.findNode("timer")
    timer.observeField("fire", "onFire")
end function

function onFire()
    anim = m.top.findNode("animInternal")
    print "anim: state: '%s' error: '%s'".Format(anim.state, anim.error)
end function
