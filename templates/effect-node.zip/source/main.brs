' Demo of the Roku OS 16.0 "Effect" node: GPU-accelerated rounded corners, borders and
' linear/radial gradients applied to Poster and Rectangle nodes via their new `effect` field.
'
' Panel 2 also demos the new "FloatArrayFieldInterpolator" node, which animates a
' field holding an array of floats - such as Effect.borderRadius - by interpolating each entry
' independently.
sub Main()
    screen = CreateObject("roSGScreen")
    port = CreateObject("roMessagePort")
    screen.setMessagePort(port)
    screen.CreateScene("EffectDemoScene")
    screen.show()

    while true
        msg = wait(0, port)
        if type(msg) = "roSGScreenEvent" and msg.isScreenClosed()
            return
        end if
    end while
end sub
